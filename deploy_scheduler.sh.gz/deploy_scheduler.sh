#!/bin/sh
APP=scheduler
DEVDIR=~/$APP
WEBDIR=/var/www/$APP
if [ ! -d $WEBDIR ]; then
	mkdir $WEBDIR
	echo "$WEBDIR does not exist."	
fi

cp  config.ru $WEBDIR
cp -r public $WEBDIR/public
cp -r tmp $WEBDIR/tmp
cp -r config $WEBDIR/config
cp -r app $WEBDIR/app


